<?php
    $con = mysqli_connect("localhost","root","","database1");
    if(!$con){
        die("Connection Error");
    }
?>