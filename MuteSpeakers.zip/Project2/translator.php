<!DOCTYPE html>
<html>
<head>
<title>translator</title>
<link rel="stylesheet" href="csst.css">
</head>
<body>
    <div class="title">
        <h1>TRANSLATOR</h1>
    <div class="background">
    </div>
    <div class ="body">
        <form action="" method="GET">
            <input type="text" name ="textg"  class="form" placeholder="Type here">
            <a href="#"> <button class="btn">Translate</button></a>

        </form>
        <hr>
        <?php
            // $con = mysqli_connect("localhost", "root", "", "database1");
            // if(isset($_GET['textg']))
            // {
            //     $textg = $_GET['textg'];
            //     $query = "SELECT image FROM signs WHERE name='$textg' ";
            //     $query_run = mysqli_query($con,$query);

            //     if(mysqli_num_rows($query_run)>0)
            //     {
            //         foreach($query_run as $row)
            //         {
            //            
            //         }
            //     }
            //     else
            //     {
            //     echo "No Record Found";
            //     }
            // }
            $connection = mysqli_connect("localhost", "root", "");
            $db = mysqli_select_db($connection, 'database1');
            // $k = $_POST["textg"];
            // $query = "SELECT * FROM `signs` WHERE name='A' ";
            $query = "SELECT * FROM `signs` WHERE name='textg' ";
            $query_run = mysqli_query($connection, $query);

            while($row = mysqli_fetch_array($query_run))
            {
                ?>
                <td> <?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'" alt="Image" style="width :200px; height:200px" >'; ?></td>
                <?php
            }
        ?>
    </div>
</body>
</html>